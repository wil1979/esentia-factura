# Configuración de Firebase para Ruleta de Premios

## Estructura de Colecciones

### 1. Colección: `participantes_ruleta`

Esta colección almacena los grupos de participantes que pueden ser utilizados en diferentes sorteos.

**Estructura de documento:**
```json
{
  "nombre": "Candelas",
  "descripcion": "Departamento de Candelas",
  "createdAt": "2024-01-15T10:30:00Z",
  "participantes": [
    {
      "id": "1",
      "nombre": "LEDA",
      "departamento": "Candelas"
    },
    {
      "id": "2",
      "nombre": "MIRIAM",
      "departamento": "Candelas"
    },
    {
      "id": "3",
      "nombre": "EVELYN",
      "departamento": "Candelas"
    }
  ]
}
```

**Campos:**
- `nombre` (String): Nombre del grupo (ej: "Candelas", "Ventas", "Recursos Humanos")
- `descripcion` (String, opcional): Descripción del grupo
- `createdAt` (Timestamp): Fecha de creación del grupo
- `participantes` (Array): Lista de participantes del grupo

---

### 2. Colección: `premios`

Almacena los ganadores actuales del sorteo en curso.

**Estructura de documento:**
```json
{
  "nombre": "LEDA",
  "departamento": "Candelas",
  "fecha": "15 de enero de 2024, 14:30",
  "posicion": 1,
  "grupoId": "candelas-dept",
  "timestamp": "2024-01-15T14:30:00Z"
}
```

**Campos:**
- `nombre` (String): Nombre del ganador
- `departamento` (String): Departamento del ganador
- `fecha` (String): Fecha y hora en formato legible
- `posicion` (Number): Posición en el sorteo (1er ganador, 2do ganador, etc.)
- `grupoId` (String): ID del grupo al que pertenece este sorteo
- `timestamp` (Timestamp): Marca de tiempo de Firebase

**Índices recomendados:**
- Índice compuesto: `grupoId` (Ascending) + `posicion` (Ascending)

---

### 3. Colección: `premios_historial`

Almacena el historial de sorteos completados, archivados automáticamente cuando se reinicia un sorteo.

**Estructura de documento:**
```json
{
  "grupoId": "candelas-dept",
  "grupoNombre": "Candelas",
  "fechaCreacion": "2024-01-22T10:00:00Z",
  "totalGanadores": 12,
  "ganadores": [
    {
      "nombre": "LEDA",
      "departamento": "Candelas",
      "posicion": 1,
      "fecha": "15 de enero de 2024, 14:30"
    },
    {
      "nombre": "MIRIAM",
      "departamento": "Candelas",
      "posicion": 2,
      "fecha": "15 de enero de 2024, 14:45"
    }
  ]
}
```

**Campos:**
- `grupoId` (String): ID del grupo del sorteo archivado
- `grupoNombre` (String): Nombre del grupo
- `fechaCreacion` (Timestamp): Fecha de creación del archivo
- `totalGanadores` (Number): Total de ganadores en este sorteo
- `ganadores` (Array): Lista de ganadores con sus datos

---

## Reglas de Seguridad de Firestore

Aquí están las reglas recomendadas para proteger tu base de datos:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Permitir lectura pública de participantes y premios
    match /participantes_ruleta/{document=**} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
    
    match /premios/{document=**} {
      allow read: if true;
      allow create: if request.auth != null || true; // Permitir sin autenticación por ahora
      allow update, delete: if request.auth != null && request.auth.token.admin == true;
    }
    
    match /premios_historial/{document=**} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
  }
}
```

---

## Cómo Crear Grupos en Firebase

### Opción 1: Desde la Consola de Firebase

1. Ve a [Firebase Console](https://console.firebase.google.com)
2. Selecciona tu proyecto
3. Ve a **Firestore Database**
4. Crea una nueva colección llamada `participantes_ruleta`
5. Agrega un documento con ID personalizado (ej: `candelas-dept`)
6. Añade los campos según la estructura anterior

### Opción 2: Usando el Script de Inicialización

Puedes crear un script Node.js para inicializar los datos:

```javascript
const admin = require('firebase-admin');
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

async function initializeGroups() {
  const groups = [
    {
      id: 'candelas-dept',
      data: {
        nombre: 'Candelas',
        descripcion: 'Departamento de Candelas',
        createdAt: new Date(),
        participantes: [
          { id: '1', nombre: 'LEDA', departamento: 'Candelas' },
          { id: '2', nombre: 'MIRIAM', departamento: 'Candelas' },
          { id: '3', nombre: 'EVELYN', departamento: 'Candelas' },
          { id: '4', nombre: 'MARLEN', departamento: 'Candelas' },
          { id: '5', nombre: 'MELISA', departamento: 'Candelas' },
          { id: '6', nombre: 'ELENA', departamento: 'Candelas' },
          { id: '7', nombre: 'HERENIA', departamento: 'Candelas' },
          { id: '8', nombre: 'PAULINA', departamento: 'Candelas' },
          { id: '9', nombre: 'KATHIA', departamento: 'Candelas' },
          { id: '10', nombre: 'DANNIA', departamento: 'Candelas' },
          { id: '11', nombre: 'PROFE MARCELA', departamento: 'Candelas' },
          { id: '12', nombre: 'ELISA', departamento: 'Candelas' }
        ]
      }
    }
  ];

  for (const group of groups) {
    await db.collection('participantes_ruleta').doc(group.id).set(group.data);
    console.log(`Grupo creado: ${group.data.nombre}`);
  }

  console.log('Inicialización completada');
  process.exit(0);
}

initializeGroups().catch(console.error);
```

---

## Flujo de Datos

### 1. Cargar Grupo
```
Usuario selecciona grupo → Carga participantes_ruleta → Filtra ganadores de premios → Renderiza ruleta
```

### 2. Girar Ruleta
```
Usuario gira → Selecciona ganador → Guarda en premios → Actualiza UI
```

### 3. Reiniciar Sorteo
```
Usuario reinicia → Archiva premios en premios_historial → Limpia premios → Recarga grupo
```

---

## Ventajas de esta Estructura

✅ **Multi-grupo:** Permite crear múltiples grupos de participantes  
✅ **Escalable:** Fácil de agregar nuevos grupos o participantes  
✅ **Historial:** Mantiene registro de todos los sorteos completados  
✅ **Flexible:** Cada grupo puede tener diferentes participantes  
✅ **Seguro:** Reglas de Firestore protegen los datos  

---

## Próximos Pasos

1. Configura los índices recomendados en Firestore
2. Ajusta las reglas de seguridad según tus necesidades
3. Crea los grupos iniciales
4. Prueba la aplicación con datos reales
