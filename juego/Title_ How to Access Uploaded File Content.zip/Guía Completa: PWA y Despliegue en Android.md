# Guía Completa: PWA y Despliegue en Android

## ¿Qué es una PWA?

Una **Progressive Web App (PWA)** es una aplicación web que combina lo mejor de las aplicaciones web y las aplicaciones nativas:

| Característica | Web App | App Nativa | PWA |
|---|---|---|---|
| Instalable | ❌ | ✅ | ✅ |
| Offline | ❌ | ✅ | ✅ |
| Notificaciones | ❌ | ✅ | ✅ |
| Pantalla de inicio | ❌ | ✅ | ✅ |
| Acceso a hardware | ❌ | ✅ | Parcial |
| Tamaño | Pequeño | Grande | Pequeño |
| Distribución | URL | App Store | URL |

---

## Archivos Necesarios para PWA

### 1. **manifest.json** - Metadatos de la Aplicación

```json
{
  "name": "Ruleta de Premios - Sorteo Dinámico",
  "short_name": "Ruleta Premios",
  "description": "Aplicación de ruleta para sorteos con gestión de grupos",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "orientation": "portrait-primary",
  "background_color": "#0f172a",
  "theme_color": "#0ea5e9",
  "icons": [...]
}
```

**Campos importantes:**
- `name`: Nombre completo (máx 45 caracteres)
- `short_name`: Nombre corto para la pantalla de inicio
- `start_url`: URL inicial de la aplicación
- `display`: "standalone" = se ve como app nativa
- `icons`: Iconos en diferentes tamaños

### 2. **sw.js** - Service Worker

El Service Worker es un script que se ejecuta en background y permite:
- Cachear recursos
- Funcionar offline
- Sincronizar datos
- Mostrar notificaciones

```javascript
const CACHE_NAME = 'ruleta-premios-v1';

self.addEventListener('install', event => {
  // Cachear recursos esenciales
});

self.addEventListener('activate', event => {
  // Limpiar caches antiguos
});

self.addEventListener('fetch', event => {
  // Interceptar solicitudes y servir desde cache si es necesario
});
```

### 3. **index.html** - Referencia a PWA

```html
<head>
  <link rel="manifest" href="manifest.json">
  <meta name="theme-color" content="#0ea5e9">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
```

---

## Checklist de Instalabilidad

Para que Android reconozca tu aplicación como PWA, debe cumplir:

- ✅ **HTTPS obligatorio** (no HTTP)
- ✅ **manifest.json válido** con campos requeridos
- ✅ **Service Worker registrado** y funcional
- ✅ **Icono de 192x192px** como mínimo
- ✅ **Nombre y descripción** en manifest
- ✅ **display: "standalone"** en manifest
- ✅ **start_url** definida
- ✅ **Viewport meta tag** en HTML

---

## Instalación en Android - Paso a Paso

### Método 1: Chrome (Recomendado)

1. **Abre Chrome** → Navega a `https://tudominio.com`
2. **Espera a que cargue completamente** (5-10 segundos)
3. **Menú (⋮)** → **"Instalar aplicación"**
4. **Confirma** → **"Instalar"**
5. **¡Listo!** Aparece en pantalla de inicio

### Método 2: Desde el Menú de Compartir

1. **Chrome** → **Menú (⋮)** → **Compartir**
2. **"Instalar aplicación"**
3. **Confirma**

### Método 3: Firefox

1. **Firefox** → Navega a la URL
2. **Menú (≡)** → **"Instalar"**
3. **Confirma**

---

## Despliegue en Servidor

### Opción 1: Vercel (Recomendado para PWA)

```bash
# Instalar Vercel CLI
npm install -g vercel

# Desplegar
vercel

# Seguir las instrucciones interactivas
```

**Ventajas:**
- HTTPS automático
- CDN global
- Actualizaciones instantáneas
- Gratis para proyectos pequeños

### Opción 2: Netlify

```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Desplegar
netlify deploy --prod

# Seguir las instrucciones
```

### Opción 3: Firebase Hosting

```bash
# Instalar Firebase CLI
npm install -g firebase-tools

# Configurar proyecto
firebase init hosting

# Desplegar
firebase deploy
```

### Opción 4: Servidor Propio (Apache/Nginx)

#### Apache (.htaccess)
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^ index.html [QSA,L]
</IfModule>

# Headers para PWA
<FilesMatch "\.json$">
  Header set Content-Type "application/json"
</FilesMatch>

<FilesMatch "\.js$">
  Header set Content-Type "application/javascript"
</FilesMatch>
```

#### Nginx
```nginx
server {
  listen 443 ssl http2;
  server_name tudominio.com;

  ssl_certificate /ruta/a/certificado.crt;
  ssl_certificate_key /ruta/a/clave.key;

  root /var/www/ruleta-premios;

  # Servir archivos estáticos
  location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
  }

  # Redirigir a index.html para rutas desconocidas
  location / {
    try_files $uri $uri/ /index.html;
  }

  # Headers para PWA
  location = /manifest.json {
    add_header Content-Type "application/json";
    expires 1w;
  }

  location = /sw.js {
    add_header Content-Type "application/javascript";
    expires 1d;
  }
}
```

---

## Estructura de Archivos en el Servidor

```
/
├── index.html              (Aplicación principal)
├── manifest.json           (Metadatos PWA)
├── sw.js                   (Service Worker)
├── .htaccess               (Configuración Apache)
├── favicon.ico             (Icono)
└── assets/
    ├── icon-192x192.png    (Icono para PWA)
    └── icon-512x512.png    (Icono grande)
```

---

## Verificación de Instalabilidad

### En Chrome DevTools

1. **Abre DevTools** (F12)
2. **Vé a Application**
3. **Verifica:**
   - ✅ **Manifest** está cargado
   - ✅ **Service Worker** está activo
   - ✅ **Cache Storage** tiene datos

### En Android

1. **Abre Chrome**
2. **Menú (⋮)** → **Configuración** → **Aplicaciones**
3. **Busca "Ruleta de Premios"**
4. **Verifica que esté instalada**

---

## Actualización de la PWA

### Versiones del Service Worker

```javascript
// Cambiar versión para forzar actualización
const CACHE_NAME = 'ruleta-premios-v2';  // Incrementar versión
```

### Estrategia de Actualización

1. **Network First**: Intenta red primero, luego cache
2. **Cache First**: Usa cache primero, luego red
3. **Stale While Revalidate**: Sirve cache mientras actualiza

```javascript
// Network First (recomendado para datos dinámicos)
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request)
      .then(response => {
        if (response.ok) {
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, response.clone());
          });
        }
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
```

---

## Características Avanzadas

### 1. Notificaciones Push

```javascript
// En el Service Worker
self.addEventListener('push', event => {
  const data = event.data.json();
  self.registration.showNotification('Ruleta de Premios', {
    body: data.body,
    icon: 'icon-192x192.png'
  });
});
```

### 2. Sincronización en Background

```javascript
// Registrar sincronización
if ('serviceWorker' in navigator && 'SyncManager' in window) {
  navigator.serviceWorker.ready.then(reg => {
    reg.sync.register('sync-winners');
  });
}

// En el Service Worker
self.addEventListener('sync', event => {
  if (event.tag === 'sync-winners') {
    event.waitUntil(syncWinnersData());
  }
});
```

### 3. Compartir Datos

```javascript
// En manifest.json
"share_target": {
  "action": "/share",
  "method": "POST",
  "enctype": "multipart/form-data",
  "params": {
    "title": "title",
    "text": "text",
    "url": "url"
  }
}
```

---

## Monitoreo y Análisis

### Verificar Instalaciones

1. **Google Play Console** (si la distribuyes como app)
2. **Analytics** en tu servidor
3. **DevTools** en dispositivos de prueba

### Métricas Importantes

- **Usuarios activos**: Cuántos usan la PWA
- **Retención**: Cuántos vuelven a usar
- **Tiempo de sesión**: Cuánto tiempo pasan
- **Errores**: Problemas reportados

---

## Solución de Problemas Comunes

| Problema | Causa | Solución |
|----------|-------|----------|
| No aparece opción instalar | Falta HTTPS o manifest | Verificar HTTPS y manifest.json |
| App se cierra | Error en JavaScript | Revisar console (F12) |
| No funciona offline | Service Worker no cacheó | Recarga la página (Ctrl+Shift+R) |
| Datos no sincronizan | Problema Firebase | Verificar conexión y credenciales |
| Icono no aparece | Ruta incorrecta | Verificar ruta en manifest.json |

---

## Distribución a Usuarios

### Método 1: Compartir URL
```
https://tudominio.com
```

### Método 2: Código QR
Usa [QR Code Generator](https://www.qr-code-generator.com/) para crear un código QR.

### Método 3: Enlace Directo
```html
<a href="https://tudominio.com" class="install-button">
  Instalar Ruleta de Premios
</a>
```

### Método 4: Email/WhatsApp
```
¡Instala la Ruleta de Premios!
https://tudominio.com

Funciona en Android, iOS y navegadores de escritorio.
```

---

## Checklist Final

- ✅ Archivos (index.html, manifest.json, sw.js) en servidor
- ✅ HTTPS habilitado
- ✅ Icono de 192x192px disponible
- ✅ Service Worker registrado
- ✅ Manifest válido
- ✅ Probado en Chrome Android
- ✅ Probado offline
- ✅ Notificaciones funcionando (si aplica)

---

## Recursos Útiles

- [MDN - Progressive Web Apps](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps)
- [Google - PWA Checklist](https://developers.google.com/web/progressive-web-apps/checklist)
- [Web.dev - PWA Guide](https://web.dev/progressive-web-apps/)
- [PWA Builder](https://www.pwabuilder.com/)

---

## Conclusión

¡Tu Ruleta de Premios es ahora una PWA completamente funcional! Los usuarios pueden:

✅ Instalarla en Android como una app nativa  
✅ Acceder desde la pantalla de inicio  
✅ Usar offline (parcialmente)  
✅ Recibir notificaciones  
✅ Sincronizar datos automáticamente  

¡Disfruta de tu aplicación!
