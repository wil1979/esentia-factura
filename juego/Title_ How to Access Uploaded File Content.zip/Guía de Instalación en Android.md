# Guía de Instalación en Android

## ¿Qué es una PWA?

Una **Progressive Web App (PWA)** es una aplicación web que se puede instalar en tu dispositivo Android como si fuera una aplicación nativa. Tiene las siguientes ventajas:

✅ No necesita descargar desde Google Play Store  
✅ Funciona offline (parcialmente)  
✅ Acceso rápido desde la pantalla de inicio  
✅ Notificaciones push  
✅ Tamaño mucho más pequeño que una app nativa  

---

## Requisitos

- **Android 5.0 o superior**
- **Chrome, Firefox, Edge o navegador compatible con PWA**
- **Conexión a Internet** (para la primera instalación)

---

## Pasos para Instalar en Android

### Método 1: Desde Chrome (Recomendado)

1. **Abre Chrome** en tu dispositivo Android
2. **Navega a la URL** de la aplicación (ej: `https://tudominio.com`)
3. **Espera a que cargue completamente** la página
4. **Toca el menú** (tres puntos verticales) en la esquina superior derecha
5. **Selecciona "Instalar aplicación"** o **"Agregar a pantalla de inicio"**
6. **Confirma la instalación** tocando "Instalar"
7. **¡Listo!** La aplicación aparecerá en tu pantalla de inicio

### Método 2: Desde el Menú de Compartir

1. **Abre Chrome** y navega a la aplicación
2. **Toca el menú** (tres puntos) → **Compartir**
3. **Selecciona "Instalar aplicación"**
4. **Confirma la instalación**

### Método 3: Desde Firefox

1. **Abre Firefox** en tu dispositivo
2. **Navega a la URL** de la aplicación
3. **Toca el menú** (tres líneas horizontales)
4. **Selecciona "Instalar"**
5. **Confirma la instalación**

---

## Después de la Instalación

### Acceder a la Aplicación

- **Desde la pantalla de inicio:** Toca el icono de la aplicación
- **Desde el menú de aplicaciones:** Busca "Ruleta de Premios"
- **Desde Chrome:** Abre Chrome → Menú → "Aplicaciones" → "Ruleta de Premios"

### Características Disponibles

✅ **Interfaz completa:** Acceso a todas las funciones  
✅ **Modo offline:** Funciona sin internet (datos cacheados)  
✅ **Notificaciones:** Recibe alertas de sorteos  
✅ **Actualización automática:** Se actualiza cuando hay cambios  

---

## Solución de Problemas

### "No aparece la opción de instalar"

**Causa:** La aplicación no es reconocida como PWA  
**Solución:**
- Asegúrate de que el archivo `manifest.json` esté correctamente configurado
- Verifica que la URL sea HTTPS (no HTTP)
- Limpia el cache de Chrome: Configuración → Aplicaciones → Chrome → Almacenamiento → Borrar datos

### "La aplicación se cierra al abrir"

**Causa:** Problema con Firebase o conectividad  
**Solución:**
- Verifica tu conexión a Internet
- Cierra y reabre la aplicación
- Desinstala y reinstala la aplicación

### "No funciona offline"

**Causa:** El Service Worker no se cargó correctamente  
**Solución:**
- Asegúrate de que `sw.js` esté en la raíz del servidor
- Verifica en Chrome DevTools → Application → Service Workers
- Recarga la página (Ctrl+Shift+R)

### "Los datos no se sincronizan"

**Causa:** Problema de conectividad con Firebase  
**Solución:**
- Verifica tu conexión a Internet
- Comprueba que Firebase está configurado correctamente
- Revisa la consola del navegador para errores

---

## Desinstalar la Aplicación

### Desde la Pantalla de Inicio

1. **Mantén presionado el icono** de la aplicación
2. **Selecciona "Desinstalar"** o **"Eliminar"**
3. **Confirma la acción**

### Desde el Menú de Aplicaciones

1. **Abre Configuración**
2. **Ve a Aplicaciones**
3. **Busca "Ruleta de Premios"**
4. **Toca "Desinstalar"**
5. **Confirma**

---

## Características Avanzadas

### Notificaciones Push

Si el servidor envía notificaciones, recibirás alertas incluso cuando la aplicación esté cerrada.

**Para habilitar notificaciones:**
1. Abre la aplicación
2. Ve a Configuración (si está disponible)
3. Activa "Notificaciones"
4. Confirma los permisos

### Sincronización en Background

La aplicación sincroniza datos automáticamente cuando recupera la conexión a Internet.

### Modo Oscuro

La aplicación se adapta automáticamente al modo oscuro de tu dispositivo.

---

## Requisitos del Servidor

Para que la PWA funcione correctamente, el servidor debe cumplir con:

✅ **HTTPS obligatorio** (no HTTP)  
✅ **manifest.json** en la raíz  
✅ **Service Worker (sw.js)** en la raíz  
✅ **Headers correctos:**
```
Content-Type: application/json (para manifest.json)
Content-Type: application/javascript (para sw.js)
```

---

## Archivos Necesarios

Para que la instalación funcione, asegúrate de que estos archivos estén en la raíz de tu servidor:

```
/
├── index.html                 (Aplicación principal)
├── manifest.json              (Configuración de PWA)
├── sw.js                       (Service Worker)
└── favicon.ico                (Icono opcional)
```

---

## Distribución a Otros Usuarios

Puedes compartir la aplicación de varias formas:

### 1. Compartir URL
```
https://tudominio.com
```
Los usuarios simplemente abren el enlace y la instalan.

### 2. Código QR
Crea un código QR que apunte a tu URL. Los usuarios lo escanean y la instalan.

### 3. Enlace Directo
```html
<a href="https://tudominio.com">Instalar Ruleta de Premios</a>
```

---

## Monitoreo y Actualizaciones

### Verificar Versión Instalada

1. **Abre la aplicación**
2. **Abre Chrome DevTools** (F12)
3. **Ve a Application → Service Workers**
4. **Verifica el estado del Service Worker**

### Actualizar la Aplicación

Las actualizaciones se descargan automáticamente. Para forzar una actualización:

1. **Abre la aplicación**
2. **Recarga la página** (Ctrl+R o desliza hacia abajo)
3. **El Service Worker descargará la versión más reciente**

---

## Soporte Técnico

Si tienes problemas con la instalación:

1. **Verifica la consola del navegador** (F12 → Console)
2. **Revisa los Service Workers** (F12 → Application → Service Workers)
3. **Limpia el cache** (Configuración → Aplicaciones → Chrome → Almacenamiento)
4. **Reinstala la aplicación**

---

## Conclusión

¡Felicidades! Ahora tienes la Ruleta de Premios instalada en tu dispositivo Android como una aplicación nativa. Disfruta de la experiencia sin necesidad de descargar desde Google Play Store.
