// Funciones para interactuar con Firebase

// Obtener todos los capítulos
async function obtenerCapitulos() {
    try {
        const capitulosRef = collection(db, 'capitulos');
        const q = query(capitulosRef, orderBy('numero', 'asc'));
        const querySnapshot = await getDocs(q);
        
        const capitulos = [];
        querySnapshot.forEach((doc) => {
            capitulos.push({
                id: doc.id,
                ...doc.data()
            });
        });
        
        console.log('📚 Capítulos obtenidos:', capitulos.length);
        return capitulos;
    } catch (error) {
        console.error('❌ Error al obtener capítulos:', error);
        return [];
    }
}

// Guardar capítulo (crear o actualizar)
async function guardarCapitulo(capitulo) {
    try {
        if (capitulo.id) {
            // Actualizar existente
            const capituloRef = doc(db, 'capitulos', capitulo.id);
            await updateDoc(capituloRef, capitulo);
            console.log('✅ Capítulo actualizado:', capitulo.numero);
        } else {
            // Crear nuevo
            const capituloRef = doc(db, 'capitulos', `cap_${capitulo.numero}`);
            await setDoc(capituloRef, capitulo);
            console.log('✅ Capítulo creado:', capitulo.numero);
        }
        return true;
    } catch (error) {
        console.error('❌ Error al guardar capítulo:', error);
        return false;
    }
}

// Eliminar capítulo
async function eliminarCapitulo(id) {
    try {
        await deleteDoc(doc(db, 'capitulos', id));
        console.log('✅ Capítulo eliminado:', id);
        return true;
    } catch (error) {
        console.error('❌ Error al eliminar capítulo:', error);
        return false;
    }
}

// Subir archivo (imagen o audio) a Firebase Storage
async function subirArchivo(file, ruta) {
    try {
        const storageRef = ref(storage, ruta);
        const snapshot = await uploadBytes(storageRef, file);
        const downloadURL = await getDownloadURL(snapshot.ref);
        console.log('✅ Archivo subido:', downloadURL);
        return downloadURL;
    } catch (error) {
        console.error(' Error al subir archivo:', error);
        return null;
    }
}

// Eliminar archivo de Firebase Storage
async function eliminarArchivo(url) {
    try {
        const fileRef = ref(storage, url);
        await deleteObject(fileRef);
        console.log('✅ Archivo eliminado:', url);
        return true;
    } catch (error) {
        console.error('❌ Error al eliminar archivo:', error);
        return false;
    }
}

// Exportar funciones
window.obtenerCapitulos = obtenerCapitulos;
window.guardarCapitulo = guardarCapitulo;
window.eliminarCapitulo = eliminarCapitulo;
window.subirArchivo = subirArchivo;
window.eliminarArchivo = eliminarArchivo;