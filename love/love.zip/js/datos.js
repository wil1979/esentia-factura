const capitulosIniciales = [
    {
        numero: 1,
        titulo: "El día que te conocí",
        lineas: [
            "No sabía que aquel día iba a cambiar mi vida.",
            "Solo sabía que gracias a un amigo nuestros caminos se cruzaron.",
            "",
            "Y después de conocerte, algo dentro de mí hizo una promesa…",
            "",
            "quería tenerte en mi vida.",
            "",
            "No sabía cuánto tiempo estarías a mi lado,",
            "ni todo lo que íbamos a vivir juntos.",
            "No sabía de los momentos difíciles,",
            "de las alegrías, de los sueños,",
            "de las risas ni de las lágrimas que vendrían.",
            "",
            "Solo sabía una cosa:",
            "quería conocerte, quería acercarme a ti",
            "y quería encontrar la manera de que formaras parte de mi vida.",
            "",
            "Y hoy, tantos años después,",
            "miro hacia atrás y pienso…",
            "",
            "qué bonito fue aquel día en que nuestros caminos se encontraron. ❤️",
            "",
            "Porque sin saberlo, aquel día no estaba conociendo solamente a una persona…",
            "estaba conociendo al amor de mi vida.",
            "",
            "W & E",
            "Una historia que comenzó aquel día… y que todavía seguimos escribiendo."
        ],
        imagenes: [
            "assets/imagenes/cap1-1.jpg",
            "assets/imagenes/cap1-1.jpg",
            "assets/imagenes/cap1-1.jpg"
        ],
        audio: "assets/audios/cap1.m4a",
        youtubeId: "a7FdUd6ysL0"
       
    },
    {
        numero: 2,
        titulo: "Nuestro amor dejó de ser de dos",
        lineas: [
            "Con el paso de los días,",
            "el amor que empecé a sentir por ti fue creciendo.",
            "",
            "Y entonces comprendí que no era una ilusión,",
            "que aquello que sentía era real…",
            "que por fin había conocido el verdadero amor a tu lado.",
            "",
            "Poco a poco nos fuimos dando cuenta",
            "de que aquello que había comenzado entre nosotros",
            "ya no era solamente un amor de dos.",
            "",
            "Había alguien más…",
            "alguien muy especial que ya comenzaba a formar parte de nuestras vidas,",
            "alguien que llevabas dentro de ti",
            "y que, sin siquiera conocer todavía su mirada,",
            "ya había comenzado a ocupar un lugar enorme en nuestros corazones.",
            "",
            "Y lejos de alejarnos,",
            "aquella noticia hizo algo maravilloso:",
            "",
            "fortaleció nuestro amor,",
            "nos unió aún más",
            "y nos hizo comenzar a soñar como familia.",
            "",
            "Desde aquel momento entendí que ya no solamente quería compartir mi vida contigo…",
            "",
            "también quería compartirla con esa personita que venía a enseñarnos una nueva forma de amar.",
            "",
            "Y así, sin darnos cuenta,",
            "aquella historia que había comenzado con dos personas",
            "empezaba a convertirse en nuestra familia. ❤️",
            "",
            "W & E",
            "Y nuestro amor comenzó a escribir un nuevo capítulo."
        ],
        imagenes: [
            "assets/imagenes/cap2-1.jpg",
            "assets/imagenes/cap2-1.jpg"
        ],
        audio: "assets/audios/cap2.mp3",
        youtubeId: ""
    },
    {
        numero: 3,
        titulo: "El día que supimos que seríamos tres",
        lineas: [
            "Recuerdo el día que juntos confirmamos",
            "que aquel amor de dos",
            "ya no volvería a ser solo de dos.",
            "",
            "Había alguien más.",
            "",
            "Y ese alguien, sin haber nacido todavía,",
            "ya estaba cambiando la manera en que veíamos la vida.",
            "",
            "Recuerdo que estábamos sentados en un parque,",
            "hablando de lo que venía,",
            "de lo que significaría,",
            "de lo que tendríamos que ser a partir de ese momento.",
            "",
            "Y entendí que el amor que nos teníamos",
            "tendría que ser lo suficientemente fuerte",
            "como para superar cada obstáculo que apareciera.",
            "",
            "Recuerdo también ese otro momento,",
            "ya más íntimo, más nuestro:",
            "sentados en la cama de tu cuarto,",
            "decidiendo juntos cómo decirle a tu madre",
            "lo que estaba por llegar a nuestras vidas.",
            "",
            "Fueron momentos duros.",
            "Momentos que pesaban.",
            "Momentos en los que tuve que buscar valor",
            "y fuerzas de donde pude",
            "para poder dar el paso.",
            "",
            "Pero ese día…",
            "ese día la vida me cambió.",
            "",
            "Y hoy, mirando hacia atrás,",
            "lo tengo claro:",
            "",
            "aquella fue la mejor decisión de mi vida. ❤️",
            "",
            "W & E",
            "Y sin saberlo, estábamos empezando a ser familia."
        ],
        imagenes: [
            "assets/imagenes/cap3-1.jpg",
            "assets/imagenes/cap3-1.jpg",
            
        ],
        audio: "assets/audios/cap3.mp3",
        youtubeId: ""
    }
];

// Cargar datos desde localStorage o usar los iniciales
let capitulos = JSON.parse(localStorage.getItem('capitulos')) || capitulosIniciales;

// Función para guardar en localStorage
function guardarEnLocalStorage() {
    localStorage.setItem('capitulos', JSON.stringify(capitulos));
}

async function migrarCapitulosIniciales() {
    console.log("⏳ Iniciando migración de los 3 capítulos...");
    
    const capitulosAMigrar = [
        {
            numero: 1,
            titulo: "El día que te conocí",
            lineas: [
                "No sabía que aquel día iba a cambiar mi vida.",
                "Solo sabía que gracias a un amigo nuestros caminos se cruzaron.",
                "",
                "Y después de conocerte, algo dentro de mí hizo una promesa…",
                "",
                "quería tenerte en mi vida.",
                "",
                "No sabía cuánto tiempo estarías a mi lado,",
                "ni todo lo que íbamos a vivir juntos.",
                "No sabía de los momentos difíciles,",
                "de las alegrías, de los sueños,",
                "de las risas ni de las lágrimas que vendrían.",
                "",
                "Solo sabía una cosa:",
                "quería conocerte, quería acercarme a ti",
                "y quería encontrar la manera de que formaras parte de mi vida.",
                "",
                "Y hoy, tantos años después,",
                "miro hacia atrás y pienso…",
                "",
                "qué bonito fue aquel día en que nuestros caminos se encontraron. ❤️",
                "",
                "Porque sin saberlo, aquel día no estaba conociendo solamente a una persona…",
                "estaba conociendo al amor de mi vida.",
                "",
                "W & E",
                "Una historia que comenzó aquel día… y que todavía seguimos escribiendo."
            ],
            imagenes: ["assets/imagenes/cap1-1.jpg", "assets/imagenes/cap1-2.jpg", "assets/imagenes/cap1-3.jpg"],
            audio: "assets/audios/cap1.m4a",
            youtubeId: "a7FdUd6ysL0"
        },
        {
            numero: 2,
            titulo: "Nuestro amor dejó de ser de dos",
            lineas: [
                "Con el paso de los días,",
                "el amor que empecé a sentir por ti fue creciendo.",
                "",
                "Y entonces comprendí que no era una ilusión,",
                "que aquello que sentía era real…",
                "que por fin había conocido el verdadero amor a tu lado.",
                "",
                "Poco a poco nos fuimos dando cuenta",
                "de que aquello que había comenzado entre nosotros",
                "ya no era solamente un amor de dos.",
                "",
                "Había alguien más…",
                "alguien muy especial que ya comenzaba a formar parte de nuestras vidas,",
                "alguien que llevabas dentro de ti",
                "y que, sin siquiera conocer todavía su mirada,",
                "ya había comenzado a ocupar un lugar enorme en nuestros corazones.",
                "",
                "Y lejos de alejarnos,",
                "aquella noticia hizo algo maravilloso:",
                "",
                "fortaleció nuestro amor,",
                "nos unió aún más",
                "y nos hizo comenzar a soñar como familia.",
                "",
                "Desde aquel momento entendí que ya no solamente quería compartir mi vida contigo…",
                "",
                "también quería compartirla con esa personita que venía a enseñarnos una nueva forma de amar.",
                "",
                "Y así, sin darnos cuenta,",
                "aquella historia que había comenzado con dos personas",
                "empezaba a convertirse en nuestra familia. ❤️",
                "",
                "W & E",
                "Y nuestro amor comenzó a escribir un nuevo capítulo."
            ],
            imagenes: ["assets/imagenes/cap2-1.jpg", "assets/imagenes/cap2-2.jpg"],
            audio: "assets/audios/cap2.mp3",
            youtubeId: ""
        },
        {
            numero: 3,
            titulo: "El día que supimos que seríamos tres",
            lineas: [
                "Recuerdo el día que juntos confirmamos",
                "que aquel amor de dos",
                "ya no volvería a ser solo de dos.",
                "",
                "Había alguien más.",
                "",
                "Y ese alguien, sin haber nacido todavía,",
                "ya estaba cambiando la manera en que veíamos la vida.",
                "",
                "Recuerdo que estábamos sentados en un parque,",
                "hablando de lo que venía,",
                "de lo que significaría,",
                "de lo que tendríamos que ser a partir de ese momento.",
                "",
                "Y entendí que el amor que nos teníamos",
                "tendría que ser lo suficientemente fuerte",
                "como para superar cada obstáculo que apareciera.",
                "",
                "Recuerdo también ese otro momento,",
                "ya más íntimo, más nuestro:",
                "sentados en la cama de tu cuarto,",
                "decidiendo juntos cómo decirle a tu madre",
                "lo que estaba por llegar a nuestras vidas.",
                "",
                "Fueron momentos duros.",
                "Momentos que pesaban.",
                "Momentos en los que tuve que buscar valor",
                "y fuerzas de donde pude",
                "para poder dar el paso.",
                "",
                "Pero ese día…",
                "ese día la vida me cambió.",
                "",
                "Y hoy, mirando hacia atrás,",
                "lo tengo claro:",
                "",
                "aquella fue la mejor decisión de mi vida. ❤️",
                "",
                "W & E",
                "Y sin saberlo, estábamos empezando a ser familia."
            ],
            imagenes: ["assets/imagenes/cap3-1.jpg", "assets/imagenes/cap3-2.jpg"],
            audio: "assets/audios/cap3.mp3",
            youtubeId: ""
        }
    ];

    try {
        for (const cap of capitulosAMigrar) {
            const docRef = window.doc(window.db, "capitulos", `cap_${cap.numero}`);
            await window.setDoc(docRef, {
                numero: cap.numero,
                titulo: cap.titulo,
                lineas: cap.lineas,
                imagenes: cap.imagenes,
                audio: cap.audio,
                youtubeId: cap.youtubeId
            });
            console.log(`✅ Capítulo ${cap.numero} guardado en Firestore`);
        }
        
        alert("🎉 ¡Migración exitosa!\n\nLos 3 capítulos ya están en Firebase con todo el texto y el video de YouTube.\n\nAHORA: Dale clic a 'Editar' en cada capítulo en esta misma página y selecciona las imágenes y audios reales de tu computadora para que se suban a la nube.");
        
        // Recargar la página para mostrar los capítulos en la lista
        location.reload(); 
        
    } catch (error) {
        console.error("❌ Error en la migración:", error);
        alert("Hubo un error. Revisa la consola (F12).");
    }
}

// Ejecutar la función
migrarCapitulosIniciales();