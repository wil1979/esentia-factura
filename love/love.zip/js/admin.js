let capituloEditando = null;

// Cargar datos al iniciar
document.addEventListener('DOMContentLoaded', function() {
    actualizarEstadisticas();
    mostrarListaCapitulos();
});

function actualizarEstadisticas() {
    const total = capitulos.length;
    document.getElementById('total-capitulos').textContent = total;
    document.getElementById('progreso').textContent = Math.round((total / 30) * 100) + '%';
}

function mostrarListaCapitulos() {
    const lista = document.getElementById('capitulos-lista');
    lista.innerHTML = '';
    
    // Ordenar por número
    const capitulosOrdenados = [...capitulos].sort((a, b) => a.numero - b.numero);
    
    capitulosOrdenados.forEach(cap => {
        const div = document.createElement('div');
        div.className = 'capitulo-item';
        div.innerHTML = `
            <div class="capitulo-header">
                <h3>Capítulo ${cap.numero}: ${cap.titulo}</h3>
                <div class="capitulo-actions">
                    <button class="btn-small btn-edit" onclick="editarCapitulo(${cap.numero})">✏️ Editar</button>
                    <button class="btn-small btn-delete" onclick="eliminarCapitulo(${cap.numero})">🗑️ Eliminar</button>
                </div>
            </div>
            <div class="capitulo-info">
                <p><strong>Líneas:</strong> ${cap.lineas.length}</p>
                <p><strong>Imagen:</strong> ${cap.imagen || 'No asignada'}</p>
                <p><strong>Audio:</strong> ${cap.audio || 'No asignado'}</p>
            </div>
        `;
        lista.appendChild(div);
    });
}

function mostrarFormulario() {
    document.getElementById('formulario').style.display = 'block';
    document.getElementById('form-titulo').textContent = 'Agregar nuevo capítulo';
    document.getElementById('cap-numero').value = capitulos.length + 1;
    document.getElementById('cap-titulo').value = '';
    document.getElementById('cap-lineas').value = '';
    document.getElementById('cap-imagen').value = '';
    document.getElementById('cap-audio').value = '';
    capituloEditando = null;
}

function cancelarFormulario() {
    document.getElementById('formulario').style.display = 'none';
    capituloEditando = null;
}

function guardarCapitulo() {
    const numero = parseInt(document.getElementById('cap-numero').value);
    const titulo = document.getElementById('cap-titulo').value.trim();
    const lineasTexto = document.getElementById('cap-lineas').value;
    const imagen = document.getElementById('cap-imagen').value.trim();
    const audio = document.getElementById('cap-audio').value.trim();
    
    if (!numero || !titulo || !lineasTexto) {
        alert('Por favor completa todos los campos obligatorios');
        return;
    }
    
    // Convertir texto en array de líneas
    const lineas = lineasTexto.split('\n');
    
    const capitulo = {
        numero: numero,
        titulo: titulo,
        lineas: lineas,
        imagen: imagen,
        audio: audio
    };
    
    if (capituloEditando !== null) {
        // Editar capítulo existente
        const index = capitulos.findIndex(c => c.numero === capituloEditando);
        if (index !== -1) {
            capitulos[index] = capitulo;
        }
    } else {
        // Verificar si ya existe un capítulo con ese número
        const existente = capitulos.findIndex(c => c.numero === numero);
        if (existente !== -1) {
            if (!confirm(`Ya existe un capítulo ${numero}. ¿Deseas reemplazarlo?`)) {
                return;
            }
            capitulos[existente] = capitulo;
        } else {
            capitulos.push(capitulo);
        }
    }
    
    // Guardar en localStorage
    guardarEnLocalStorage();
    
    // Actualizar interfaz
    cancelarFormulario();
    actualizarEstadisticas();
    mostrarListaCapitulos();
    
    alert('✅ Capítulo guardado correctamente');
}

function editarCapitulo(numero) {
    const capitulo = capitulos.find(c => c.numero === numero);
    if (!capitulo) return;
    
    document.getElementById('formulario').style.display = 'block';
    document.getElementById('form-titulo').textContent = `Editar capítulo ${numero}`;
    document.getElementById('cap-numero').value = capitulo.numero;
    document.getElementById('cap-titulo').value = capitulo.titulo;
    document.getElementById('cap-lineas').value = capitulo.lineas.join('\n');
    document.getElementById('cap-imagen').value = capitulo.imagen || '';
    document.getElementById('cap-audio').value = capitulo.audio || '';
    
    capituloEditando = numero;
    
    // Scroll al formulario
    document.getElementById('formulario').scrollIntoView({ behavior: 'smooth' });
}

function eliminarCapitulo(numero) {
    if (!confirm(`¿Estás seguro de que deseas eliminar el capítulo ${numero}?`)) {
        return;
    }
    
    capitulos = capitulos.filter(c => c.numero !== numero);
    guardarEnLocalStorage();
    actualizarEstadisticas();
    mostrarListaCapitulos();
    
    alert('✅ Capítulo eliminado');
}

function exportarDatos() {
    const dataStr = JSON.stringify(capitulos, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `capitulos-w-e-${new Date().toISOString().split('T')[0]}.json`;
    link.click();
    
    URL.revokeObjectURL(url);
}

function importarDatos(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const datos = JSON.parse(e.target.result);
            
            if (!Array.isArray(datos)) {
                throw new Error('Formato inválido');
            }
            
            if (confirm(`Se importarán ${datos.length} capítulos. ¿Los capítulos existentes serán reemplazados?`)) {
                capitulos = datos;
                guardarEnLocalStorage();
                actualizarEstadisticas();
                mostrarListaCapitulos();
                alert('✅ Datos importados correctamente');
            }
        } catch (error) {
            alert('❌ Error al importar: ' + error.message);
        }
    };
    reader.readAsText(file);
    
    // Reset input
    event.target.value = '';
}