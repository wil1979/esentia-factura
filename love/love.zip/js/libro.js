// Variables globales
let capitulos = [];
let capituloActual = 0;
let player;
let youtubeReady = false;
let carruselActual = 0;
let intervaloTexto;
let lineaActual = 0;
let lineasFiltradas = [];
let musicaActivada = false;
let videoIdPendiente = null;
let audioActual = null;

// Inicializar YouTube API
function onYouTubeIframeAPIReady() {
    youtubeReady = true;
    console.log('✅ YouTube API lista');
}

// Cargar capítulos desde Firebase al iniciar
async function inicializarLibro() {
    console.log('📖 Cargando capítulos desde Firebase...');
    
    try {
        capitulos = await window.obtenerCapitulos();
        
        if (capitulos.length === 0) {
            console.warn('⚠️ No hay capítulos en Firebase');
            alert('Aún no hay capítulos. Agrega algunos desde el panel de administración.');
            return;
        }
        
        console.log(`✅ ${capitulos.length} capítulos cargados`);
        
        // Mostrar portada con botón
        document.querySelector('.portada .descripcion').textContent = 
            `${capitulos.length} capítulos de amor ❤️`;
        document.querySelector('.portada .loading').style.display = 'none';
        
    } catch (error) {
        console.error('❌ Error al cargar capítulos:', error);
        document.querySelector('.portada .descripcion').textContent = 
            'Error al cargar la historia. Recarga la página.';
    }
}

function abrirLibro() {
    document.getElementById('portada').style.display = 'none';
    document.getElementById('pagina').style.display = 'block';
    document.getElementById('pagina').classList.add('activa');
    document.getElementById('btn-activar-musica').style.display = 'block';
    
    if (capitulos.length > 0) {
        mostrarCapitulo(0);
    }
}

function activarMusica() {
    console.log('🎵 Activando música...');
    
    musicaActivada = true;
    document.getElementById('btn-activar-musica').style.display = 'none';
    
    if (videoIdPendiente) {
        reproducirYouTube(videoIdPendiente);
        videoIdPendiente = null;
    }
    
    if (capitulos[capituloActual] && capitulos[capituloActual].audio) {
        reproducirAudioLocal(capitulos[capituloActual].audio);
    }
}

function reproducirAudioLocal(rutaAudio) {
    if (audioActual) {
        audioActual.pause();
        audioActual = null;
    }
    
    audioActual = new Audio(rutaAudio);
    audioActual.volume = 0.7;
    
    audioActual.play().catch(error => {
        console.error('❌ Error al reproducir audio:', error);
        console.log('📁 Ruta del audio:', rutaAudio);
    });
}

function mostrarCapitulo(index) {
    const capitulo = capitulos[index];
    
    carruselActual = 0;
    
    document.getElementById('titulo-capitulo').textContent = capitulo.titulo;
    
    configurarCarrusel(capitulo.imagenes || [capitulo.imagen]);
    
    iniciarEfectoTextoFijo(capitulo.lineas);
    
    document.getElementById('indicador-pagina').textContent = 
        `Capítulo ${capitulo.numero} de ${capitulos.length}`;
    
    document.getElementById('btn-anterior').disabled = index === 0;
    document.getElementById('btn-siguiente').disabled = index === capitulos.length - 1;
    
    if (capitulo.youtubeId && youtubeReady) {
        if (musicaActivada) {
            reproducirYouTube(capitulo.youtubeId);
        } else {
            videoIdPendiente = capitulo.youtubeId;
        }
    } else if (capitulo.audio && musicaActivada) {
        reproducirAudioLocal(capitulo.audio);
    }
    
    capituloActual = index;
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ... (resto de las funciones de carrusel, texto, YouTube igual que antes)

// Carrusel de imágenes
function configurarCarrusel(imagenes) {
    const carrusel = document.getElementById('carrusel');
    const indicadoresContainer = document.getElementById('carrusel-indicadores');
    
    carrusel.innerHTML = '';
    indicadoresContainer.innerHTML = '';
    
    imagenes.forEach((img, index) => {
        const imgElement = document.createElement('img');
        imgElement.src = img;
        imgElement.alt = `Imagen ${index + 1}`;
        imgElement.className = 'carrusel-imagen';
        imgElement.onerror = function() {
            this.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="600" height="400"%3E%3Crect fill="%23f0f0f0" width="600" height="400"/%3E%3Ctext fill="%23999" font-family="Arial" font-size="20" x="50%25" y="50%25" text-anchor="middle" dy=".3em"%3EImagen ' + (index + 1) + '%3C/text%3E%3C/svg%3E';
        };
        carrusel.appendChild(imgElement);
        
        const punto = document.createElement('div');
        punto.className = 'indicador-punto' + (index === 0 ? ' activo' : '');
        punto.onclick = () => irACarrusel(index);
        indicadoresContainer.appendChild(punto);
    });
    
    actualizarCarrusel();
}

function actualizarCarrusel() {
    const carrusel = document.getElementById('carrusel');
    carrusel.style.transform = `translateX(-${carruselActual * 100}%)`;
    
    const puntos = document.querySelectorAll('.indicador-punto');
    puntos.forEach((punto, index) => {
        punto.classList.toggle('activo', index === carruselActual);
    });
    
    document.getElementById('btn-carrusel-prev').style.display = carruselActual === 0 ? 'none' : 'flex';
    document.getElementById('btn-carrusel-next').style.display = carruselActual === document.querySelectorAll('.carrusel-imagen').length - 1 ? 'none' : 'flex';
}

function carruselPrev() {
    if (carruselActual > 0) {
        carruselActual--;
        actualizarCarrusel();
    }
}

function carruselNext() {
    const totalImagenes = document.querySelectorAll('.carrusel-imagen').length;
    if (carruselActual < totalImagenes - 1) {
        carruselActual++;
        actualizarCarrusel();
    }
}

function irACarrusel(index) {
    carruselActual = index;
    actualizarCarrusel();
}

function iniciarEfectoTextoFijo(lineas) {
    const lineaActualEl = document.getElementById('linea-actual');
    const lineaSiguienteEl = document.getElementById('linea-siguiente');
    
    if (intervaloTexto) {
        clearInterval(intervaloTexto);
    }
    
    lineasFiltradas = lineas.filter(linea => linea.trim() !== '');
    
    lineaActual = 0;
    
    if (lineasFiltradas.length > 0) {
        lineaActualEl.textContent = lineasFiltradas[0];
        lineaActualEl.className = 'linea-actual';
        lineaSiguienteEl.textContent = '';
        lineaSiguienteEl.className = 'linea-siguiente';
    }
    
    setTimeout(() => {
        if (lineasFiltradas.length > 1) {
            lineaSiguienteEl.textContent = lineasFiltradas[1];
            lineaSiguienteEl.className = 'linea-siguiente fade-in';
        }
        
        lineaActual = 2;
        
        intervaloTexto = setInterval(() => {
            if (lineaActual < lineasFiltradas.length) {
                lineaActualEl.className = 'linea-actual fade-out';
                
                setTimeout(() => {
                    lineaActualEl.textContent = lineasFiltradas[lineaActual - 1];
                    lineaActualEl.className = 'linea-actual';
                    
                    if (lineaActual < lineasFiltradas.length) {
                        lineaSiguienteEl.textContent = lineasFiltradas[lineaActual];
                        lineaSiguienteEl.className = 'linea-siguiente fade-in';
                    } else {
                        lineaSiguienteEl.textContent = '';
                        lineaSiguienteEl.className = 'linea-siguiente';
                    }
                    
                    lineaActual++;
                }, 1500);
            } else {
                clearInterval(intervaloTexto);
            }
        }, 5000);
    }, 2000);
}

function reproducirYouTube(videoId) {
    console.log('🎬 Reproduciendo YouTube:', videoId);
    
    const youtubeContainer = document.getElementById('youtube-container');
    youtubeContainer.style.display = 'block';
    youtubeContainer.classList.remove('muted');
    
    if (player) {
        console.log('🔄 Cargando video en player existente');
        player.loadVideoById({
            videoId: videoId,
            suggestedQuality: 'small'
        });
        
        setTimeout(() => {
            player.unMute();
            player.setVolume(70);
            player.playVideo();
        }, 500);
    } else {
        console.log('🆕 Creando nuevo player');
        player = new YT.Player('player', {
            height: '100%',
            width: '100%',
            videoId: videoId,
            playerVars: {
                'autoplay': 1,
                'controls': 0,
                'modestbranding': 1,
                'rel': 0,
                'playsinline': 1,
                'mute': 0,
                'origin': window.location.origin
            },
            events: {
                'onReady': onPlayerReady,
                'onStateChange': onPlayerStateChange,
                'onError': onPlayerError
            }
        });
    }
}

function onPlayerReady(event) {
    console.log('✅ Player listo');
    event.target.unMute();
    event.target.setVolume(70);
    event.target.playVideo();
    
    setTimeout(() => {
        const state = event.target.getPlayerState();
        console.log('Estado del player:', state);
        
        if (state !== 1) {
            console.log('⚠️ No se está reproduciendo, intentando de nuevo...');
            event.target.playVideo();
        }
    }, 1000);
}

function onPlayerStateChange(event) {
    console.log('📊 Estado cambiado:', event.data);
    
    if (event.data === 1) {
        console.log('▶️ Reproduciendo');
        document.getElementById('youtube-container').classList.remove('muted');
    } else if (event.data === 2) {
        console.log('⏸️ Pausado');
    } else if (event.data === 0) {
        console.log('⏹️ Terminado');
    }
}

function onPlayerError(event) {
    console.error('❌ Error en el reproductor YouTube:', event.data);
    
    const errores = {
        2: 'ID de video inválido',
        5: 'Error en el reproductor HTML5',
        100: 'Video no encontrado',
        101: 'Video no permite reproducción embebida',
        150: 'Video no permite reproducción embebida'
    };
    
    console.error('Detalle:', errores[event.data] || 'Error desconocido');
    document.getElementById('youtube-container').classList.add('muted');
}

function cerrarYouTube() {
    const youtubeContainer = document.getElementById('youtube-container');
    youtubeContainer.style.display = 'none';
    
    if (player) {
        player.stopVideo();
    }
}

function paginaAnterior() {
    if (capituloActual > 0) {
        if (intervaloTexto) clearInterval(intervaloTexto);
        mostrarCapitulo(capituloActual - 1);
    }
}

function paginaSiguiente() {
    if (capituloActual < capitulos.length - 1) {
        if (intervaloTexto) clearInterval(intervaloTexto);
        mostrarCapitulo(capituloActual + 1);
    }
}

document.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowLeft') {
        paginaAnterior();
    } else if (e.key === 'ArrowRight') {
        paginaSiguiente();
    } else if (e.key === 'Escape') {
        cerrarYouTube();
    }
});

// Inicializar al cargar la página
document.addEventListener('DOMContentLoaded', inicializarLibro);