# W & E - 19 años de amor ❤️

Una historia de amor contada en 30 capítulos, presentada como un libro digital interactivo.

## 📖 Descripción

Este proyecto es un libro digital que cuenta la historia de W & E a lo largo de 19 años. Cada capítulo representa un momento especial de su historia, con texto, imágenes y audio.

## 🚀 Características

- ✅ Libro digital interactivo con animaciones
- ✅ Panel de administración para gestionar capítulos
- ✅ Texto aparece línea por línea con animaciones
- ✅ Soporte para imágenes y audio en cada capítulo
- ✅ Navegación con botones y teclado
- ✅ Diseño responsive (funciona en móvil y desktop)
- ✅ Datos guardados en localStorage (próximamente Firebase)

## 📁 Estructura del proyecto
